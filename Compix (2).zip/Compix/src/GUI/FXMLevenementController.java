/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import entity.Evenement;
import java.net.URL;
import java.sql.Date;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import service.ServiceEvenement;

/**
 * FXML Controller class
 *

 */
public class FXMLevenementController implements Initializable {

    @FXML
    private TextField tftype;
    @FXML
    private TableView<Evenement> tableview;
    @FXML
    private TableColumn<Evenement, Integer> columnid;
    @FXML
    private TableColumn<Evenement, String> columntype;
    @FXML
    private TableColumn<Evenement, String> columnlieu;
    @FXML
    private TableColumn<Evenement, Date> columndatedebut;
    @FXML
    private TableColumn<Evenement, Date> columndatefin;
    @FXML
    private TextField tflieu;
    @FXML
    private DatePicker dpdatedebut;
    @FXML
    private DatePicker dpdatefin;
    @FXML
    private TextField tfrecherche;
    ServiceEvenement se=new ServiceEvenement();
    ObservableList<Evenement> data=FXCollections.observableArrayList();

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        refresh();
    }    

   

    @FXML
    private void ajouter(ActionEvent event) {
        
        Evenement e=new Evenement(tftype.getText(),Date.valueOf(dpdatedebut.getValue()) , Date.valueOf(dpdatefin.getValue()), tflieu.getText());
        se.ajouter(e);
        refresh();
    }

    @FXML
    private void modifier(ActionEvent event) {
        int idmodif=tableview.getSelectionModel().getSelectedItem().getId();
        Evenement e=new Evenement(tftype.getText(),Date.valueOf(dpdatedebut.getValue()) , Date.valueOf(dpdatefin.getValue()), tflieu.getText());
        se.modifier(e, idmodif);
        refresh();
    }
    

    @FXML
    private void supprimer(ActionEvent event) {
        int idsupp=tableview.getSelectionModel().getSelectedItem().getId();
        se.supprimer(idsupp);
        refresh();
    }
    public void refresh(){
        data.clear();
        data=FXCollections.observableArrayList(se.afficher());
        columnid.setCellValueFactory(new PropertyValueFactory<>("id"));
        columnlieu.setCellValueFactory(new PropertyValueFactory<>("lieu"));
        columntype.setCellValueFactory(new PropertyValueFactory<>("type"));
        columndatedebut.setCellValueFactory(new PropertyValueFactory<>("date_debut"));
        columndatefin.setCellValueFactory(new PropertyValueFactory<>("date_fin"));
        tableview.setItems(data);
    }
    
}
